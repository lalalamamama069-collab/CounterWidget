package com.example.counterwidget

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

object CounterStorage {

    private const val PREFS_NAME = "counter_prefs"
    private const val KEY_CURRENT_COUNT = "current_count"
    private const val KEY_HISTORY_PREFIX = "history_"
    const val DEFAULT_COUNT = 20

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getCurrentCount(context: Context): Int =
        prefs(context).getInt(KEY_CURRENT_COUNT, DEFAULT_COUNT)

    fun setCurrentCount(context: Context, count: Int) {
        prefs(context).edit().putInt(KEY_CURRENT_COUNT, count).apply()
    }

    fun decreaseCount(context: Context): Int {
        val current = getCurrentCount(context)
        val newCount = if (current > 0) current - 1 else 0
        setCurrentCount(context, newCount)
        return newCount
    }

    fun resetCount(context: Context) {
        val currentCount = getCurrentCount(context)
        val today = getTodayDateString()
        saveDayHistory(context, today, currentCount)
        setCurrentCount(context, DEFAULT_COUNT)
    }

    private fun saveDayHistory(context: Context, date: String, finalCount: Int) {
        prefs(context).edit().putInt("$KEY_HISTORY_PREFIX$date", finalCount).apply()
    }

    fun getHistory(context: Context): List<DayRecord> {
        val allPrefs = prefs(context).all
        val records = mutableListOf<DayRecord>()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        for ((key, value) in allPrefs) {
            if (key.startsWith(KEY_HISTORY_PREFIX) && value is Int) {
                val dateStr = key.removePrefix(KEY_HISTORY_PREFIX)
                try {
                    val date = dateFormat.parse(dateStr)
                    if (date != null) {
                        records.add(DayRecord(date, dateStr, value))
                    }
                } catch (e: Exception) {
                    // skip
                }
            }
        }
        return records.sortedByDescending { it.date }
    }

    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    data class DayRecord(
        val date: Date,
        val dateString: String,
        val finalCount: Int
    )
}
