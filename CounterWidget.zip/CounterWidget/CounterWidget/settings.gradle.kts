rootProject.name = "CounterWidget"
include(":app")