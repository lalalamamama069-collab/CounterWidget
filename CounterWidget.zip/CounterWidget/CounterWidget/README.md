# Counter Widget App

Android-App mit:
- Counter ab 20
- Widget
- Tagesreset um Mitternacht
- Verlauf der Tagesstände

## Öffnen

1. ZIP entpacken
2. In Android Studio öffnen
3. Gradle sync starten
4. APK builden