package com.example.counterwidget

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        MidnightResetReceiver.scheduleMidnightReset(this)
        setupCurrentCount()
        setupHistory()
    }

    override fun onResume() {
        super.onResume()
        setupCurrentCount()
        setupHistory()
    }

    private fun setupCurrentCount() {
        val count = CounterStorage.getCurrentCount(this)
        val tvCurrentCount = findViewById<TextView>(R.id.tv_current_count)
        val tvCurrentLabel = findViewById<TextView>(R.id.tv_current_label)
        tvCurrentCount.text = count.toString()
        val color = when {
            count > 15 -> getColor(R.color.count_high)
            count > 8  -> getColor(R.color.count_mid)
            count > 3  -> getColor(R.color.count_low)
            else       -> getColor(R.color.count_critical)
        }
        tvCurrentCount.setTextColor(color)
        val pct = (count / 20f * 100).toInt()
        tvCurrentLabel.text = "Heute noch $pct% übrig"
    }

    private fun setupHistory() {
        val history = CounterStorage.getHistory(this)
        val recycler = findViewById<RecyclerView>(R.id.rv_history)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = HistoryAdapter(history)
        val tvEmpty = findViewById<TextView>(R.id.tv_empty)
        tvEmpty.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE
    }
}

class HistoryAdapter(
    private val records: List<CounterStorage.DayRecord>
) : RecyclerView.Adapter<HistoryAdapter.VH>() {

    private val displayFormat = SimpleDateFormat("EEEE, dd. MMMM yyyy", Locale.GERMAN)

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDate: TextView = itemView.findViewById(R.id.tv_date)
        val tvFinalCount: TextView = itemView.findViewById(R.id.tv_final_count)
        val tvBar: View = itemView.findViewById(R.id.v_bar)
        val tvRemark: TextView = itemView.findViewById(R.id.tv_remark)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val record = records[position]
        val ctx = holder.itemView.context
        holder.tvDate.text = displayFormat.format(record.date)
        holder.tvFinalCount.text = record.finalCount.toString()
        val color = when {
            record.finalCount > 15 -> ctx.getColor(R.color.count_high)
            record.finalCount > 8  -> ctx.getColor(R.color.count_mid)
            record.finalCount > 3  -> ctx.getColor(R.color.count_low)
            else                   -> ctx.getColor(R.color.count_critical)
        }
        holder.tvFinalCount.setTextColor(color)
        val params = holder.tvBar.layoutParams
        val density = ctx.resources.displayMetrics.density
        params.width = ((record.finalCount / 20f) * 200 * density).toInt().coerceAtLeast((4 * density).toInt())
        holder.tvBar.layoutParams = params
        holder.tvBar.setBackgroundColor(color)
        holder.tvRemark.text = when {
            record.finalCount == 20 -> "Perfekt – nichts verbraucht! 🏆"
            record.finalCount > 15  -> "Sehr gut – kaum genutzt 💪"
            record.finalCount > 10  -> "Gut – noch reichlich übrig 👍"
            record.finalCount > 5   -> "Okay – mehr als die Hälfte weg"
            record.finalCount > 0   -> "Knapp – fast aufgebraucht ⚠️"
            else                    -> "Alles verbraucht – null erreicht! 🔴"
        }
    }

    override fun getItemCount() = records.size
}
